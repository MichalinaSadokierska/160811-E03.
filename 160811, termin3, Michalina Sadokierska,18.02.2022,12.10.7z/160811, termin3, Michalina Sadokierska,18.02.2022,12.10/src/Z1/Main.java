package Z1;
import java.lang.Integer;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Arrays;
import java.time.LocalDate;

class Main {
    public static void main(String[] args){
        Integer[] integers_element = {1,2,3,4};
        Integer[] integers_element1 = {3,5,6,5};

        System.out.println(integers_element);
        System.out.println(integers_element1);

        LocalDate[] dates_element = new LocalDate();
        LocalTime.of(10,15);
        LocalDate[] dates_element_1 = new LocalDate();
        LocalTime.of(11,16);
        System.out.println(Arrays.toString(dates_element));
        System.out.println(dates_element_1);
    }
}
