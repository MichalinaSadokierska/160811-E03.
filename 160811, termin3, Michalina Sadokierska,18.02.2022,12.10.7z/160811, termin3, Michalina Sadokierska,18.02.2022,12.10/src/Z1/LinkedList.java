package Z1;

public class LinkedList {
    public <T extends Comparable<? super T>> boolean LinkedList(T[] tab){
        for (int i=0; i< tab.length -1; i++){
            if (tab[i].compareTo (tab[i+1])>0){
                return false;
            }
        }
        return true;
    }
}
