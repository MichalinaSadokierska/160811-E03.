package Z3;

import java.io.File;
import java.util.Arrays;

public class Main {
    public static void main (String[] args){
        File katalog_1 = new File("C/Program Files");
        File[] katalog = Funkcja.wszystkiekatalogow(katalog_1);
        System.out.println(Arrays.toString(katalog_1));
        System.out.println(Arrays.toString(katalog));
    }
}
