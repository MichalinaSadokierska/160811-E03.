package Z3;

import java.io.File;
import java.util.List;

public class Funkcja {
    public static File[] wszystkiekatalogow(File katalog) {
        return new File[0];
    }
}
