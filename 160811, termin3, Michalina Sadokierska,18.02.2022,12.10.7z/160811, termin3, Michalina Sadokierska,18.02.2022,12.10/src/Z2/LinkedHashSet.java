package Z2;

public class LinkedHashSet {
    public void iterator() {
    }
}
