package Z2;

import java.util.Arrays;
import java.util.Iterator;

public class Main {
    public static void main(String[] args){
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        linkedHashSet.add("A");
        linkedHashSet.add("B");
        linkedHashSet.add("C");

        Iterator to = linkedHashSet.iterator();
        System.out.println("Elementy w linkedHashSet: ");
        while(is.hasNext());

        System.out.println(is.next());
    }
}
